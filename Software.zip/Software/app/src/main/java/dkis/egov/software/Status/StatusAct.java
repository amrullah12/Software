package dkis.egov.software.Status;

public class StatusAct {
}
