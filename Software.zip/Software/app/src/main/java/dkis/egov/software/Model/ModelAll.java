package dkis.egov.software.Model;

public class ModelAll {
}
