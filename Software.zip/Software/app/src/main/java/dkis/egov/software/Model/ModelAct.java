package dkis.egov.software.Model;

public class ModelAct {
}
