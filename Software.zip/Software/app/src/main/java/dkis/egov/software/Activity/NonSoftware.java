package dkis.egov.software.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import dkis.egov.software.R;

public class NonSoftware extends AppCompatActivity {

    public String URL = "http://software.appdevel.cirebonkota.go.id/api/swall.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_software);
    }
}
