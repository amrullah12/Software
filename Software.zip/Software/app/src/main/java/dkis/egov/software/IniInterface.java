package dkis.egov.software;

public interface IniInterface {

}
