package dkis.egov.software.Status;

public class StatusAll {
}
